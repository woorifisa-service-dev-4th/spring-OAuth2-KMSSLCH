-- ========================================================================
-- 1. security 스키마: OAuth 인증/인가 관련 데이터 저장
-- ========================================================================

-- 기존에 존재하면 삭제 후 생성 (운영 환경에서는 DROP 구문 주의)
DROP DATABASE IF EXISTS security;
CREATE DATABASE security CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE security;

-- OAuth 클라이언트 정보 저장 테이블
CREATE TABLE clients (
                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                         client_id VARCHAR(255) NOT NULL UNIQUE,         -- OAuth 클라이언트 식별자
                         client_secret VARCHAR(255) NOT NULL,              -- 클라이언트 시크릿
                         redirect_uri VARCHAR(1024) NOT NULL,              -- 등록된 리다이렉트 URI
                         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP    -- 생성 시간
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 인가 코드 저장 테이블
CREATE TABLE authorization_codes (
                                     id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                     code VARCHAR(255) NOT NULL UNIQUE,                -- 발급된 인증 코드
                                     client_id VARCHAR(255) NOT NULL,                  -- 연관된 클라이언트 식별자
                                     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   -- 생성 시간
                                     expires_at TIMESTAMP NOT NULL,                    -- 만료 시간
                                     CONSTRAINT fk_client_code FOREIGN KEY (client_id) REFERENCES clients(client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 액세스 토큰 저장 테이블
CREATE TABLE access_tokens (
                               id BIGINT AUTO_INCREMENT PRIMARY KEY,
                               token VARCHAR(255) NOT NULL UNIQUE,               -- 발급된 액세스 토큰
                               client_id VARCHAR(255) NOT NULL,                  -- 연관된 클라이언트 식별자
                               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   -- 생성 시간
                               expires_in INT NOT NULL,                          -- 유효기간(초 단위)
                               CONSTRAINT fk_client_token FOREIGN KEY (client_id) REFERENCES clients(client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 필요 시 리프레시 토큰 테이블 등 추가 구현 가능


-- ========================================================================
-- 2. userdata 스키마: 사용자 정보 저장
-- ========================================================================

DROP DATABASE IF EXISTS userdata;
CREATE DATABASE userdata CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE userdata;

-- 사용자 정보 테이블
CREATE TABLE users (
                       id BIGINT AUTO_INCREMENT PRIMARY KEY,
                       username VARCHAR(255) NOT NULL UNIQUE,          -- 사용자명 (로그인 ID)
                       password VARCHAR(255) NOT NULL,                   -- 암호화된 비밀번호
                       email VARCHAR(255) NOT NULL UNIQUE,               -- 이메일 주소
                       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   -- 가입일
                       updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP -- 최근 수정일
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
